<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="scripts/verificar.js">
    </script>
</head>
<body>
    <label for="idEmail"> Email:</label>
    <br>
    <input type="email" id="idEmail" name="correo">
    <br>
    <label for="idPass"> password </label>
    <br>
    <input type="password" id="idPass" name="clave">
    <br>
    <button id="accion" value="verificar"> verificar </button>
    </form>
</body>
</html>